import pygame
import sys
import math
import random
from pygame import gfxdraw

# Initialize pygame
pygame.init()
pygame.mixer.init()

# Constants
WIDTH, HEIGHT = 800, 800
BOARD_SIZE = 700
POCKET_RADIUS = 45  
COIN_RADIUS = 20
STRIKER_RADIUS = 25
RED_COIN_RADIUS = 22
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
BLUE = (0, 0, 255)
YELLOW = (255, 255, 0)
BOARD_COLOR = (210, 180, 140)
LINE_COLOR = (0, 0, 0)
PLAYER_STRIKER_COLOR = BLUE
AI_STRIKER_COLOR = YELLOW
FRICTION = 0.98
MIN_VELOCITY = 0.1
MAX_POWER = 35  # Increased max power

# Game states
WAITING_FOR_STRIKE = 0
PLAYER_TURN = 1
AI_TURN = 2
GAME_OVER = 3

class Coin:
    def __init__(self, x, y, color, is_queen=False):
        self.x = x
        self.y = y
        self.color = color
        self.radius = RED_COIN_RADIUS if is_queen else COIN_RADIUS
        self.vx = 0
        self.vy = 0
        self.is_queen = is_queen
        self.in_pocket = False
        self.pocketed_this_turn = False
    
    def update(self):
        self.x += self.vx
        self.y += self.vy
        self.vx *= FRICTION
        self.vy *= FRICTION
        if abs(self.vx) < MIN_VELOCITY and abs(self.vy) < MIN_VELOCITY:
            self.vx = 0
            self.vy = 0
    
    def draw(self, screen):
        if not self.in_pocket:
            pygame.gfxdraw.filled_circle(screen, int(self.x), int(self.y), self.radius, self.color)
            pygame.gfxdraw.aacircle(screen, int(self.x), int(self.y), self.radius, BLACK)
    
    def check_pocket_collision(self, pockets):
        for pocket in pockets:
            distance = math.sqrt((self.x - pocket[0])**2 + (self.y - pocket[1])**2)
            if distance < POCKET_RADIUS:
                self.in_pocket = True
                self.pocketed_this_turn = True
                return True
        return False
    
    def check_wall_collision(self, board_rect):
        if self.x - self.radius < board_rect.left:
            self.x = board_rect.left + self.radius
            self.vx = -self.vx * 0.8
        elif self.x + self.radius > board_rect.right:
            self.x = board_rect.right - self.radius
            self.vx = -self.vx * 0.8
        if self.y - self.radius < board_rect.top:
            self.y = board_rect.top + self.radius
            self.vy = -self.vy * 0.8
        elif self.y + self.radius > board_rect.bottom:
            self.y = board_rect.bottom - self.radius
            self.vy = -self.vy * 0.8
    
    def check_coin_collision(self, other):
        if self.in_pocket or other.in_pocket:
            return False
        
        dx = other.x - self.x
        dy = other.y - self.y
        distance = math.sqrt(dx**2 + dy**2)
        
        if distance < self.radius + other.radius:
            nx = dx / distance
            ny = dy / distance
            rvx = other.vx - self.vx
            rvy = other.vy - self.vy
            velocity_along_normal = rvx * nx + rvy * ny
            
            if velocity_along_normal > 0:
                return False
            
            impulse = -(1 + 0.8) * velocity_along_normal
            impulse /= 1 / 1 + 1 / 1
            
            self.vx -= impulse * nx / 1
            self.vy -= impulse * ny / 1
            other.vx += impulse * nx / 1
            other.vy += impulse * ny / 1
            
            overlap = (self.radius + other.radius - distance) * 0.5
            self.x -= overlap * nx
            self.y -= overlap * ny
            other.x += overlap * nx
            other.y += overlap * ny
            
            return True
        return False

class Striker:
    def __init__(self, x, y, is_player=True):
        self.x = x
        self.y = y
        self.radius = STRIKER_RADIUS
        self.vx = 0
        self.vy = 0
        self.is_player = is_player
        self.original_y = y
        self.original_x = x
        self.power = 0
        self.angle = 0
        self.charging = False
        self.max_power = MAX_POWER
        self.color = PLAYER_STRIKER_COLOR if is_player else AI_STRIKER_COLOR
        self.line_pos = y
        self.visible = True  # Always visible now
    
    def reset_position(self):
        self.x = self.original_x
        self.y = self.original_y
        self.vx = 0
        self.vy = 0
        self.visible = True  # Always visible
    
    def update(self):
        self.x += self.vx
        self.y += self.vy
        self.vx *= FRICTION
        self.vy *= FRICTION
        if abs(self.vx) < MIN_VELOCITY and abs(self.vy) < MIN_VELOCITY:
            self.vx = 0
            self.vy = 0
    
    def draw(self, screen, game_state, board_rect):
        if not self.visible:
            return
            
        pygame.gfxdraw.filled_circle(screen, int(self.x), int(self.y), self.radius, self.color)
        pygame.gfxdraw.aacircle(screen, int(self.x), int(self.y), self.radius, BLACK)
        
        if self.charging:
            end_x = self.x - math.cos(self.angle) * self.power * 5
            end_y = self.y - math.sin(self.angle) * self.power * 5
            pygame.draw.line(screen, RED, (self.x, self.y), (end_x, end_y), 2)
            
            if self.is_player:
                predicted_x, predicted_y = self.x, self.y
                predicted_vx = math.cos(self.angle) * self.power
                predicted_vy = math.sin(self.angle) * self.power
                
                for _ in range(20):
                    new_x = predicted_x + predicted_vx
                    new_y = predicted_y + predicted_vy
                    
                    if new_x - self.radius < board_rect.left or new_x + self.radius > board_rect.right:
                        predicted_vx *= -0.8
                    if new_y - self.radius < board_rect.top or new_y + self.radius > board_rect.bottom:
                        predicted_vy *= -0.8
                    
                    pygame.draw.line(screen, (0, 255, 0, 100), (predicted_x, predicted_y), (new_x, new_y), 1)
                    predicted_x, predicted_y = new_x, new_y
                    predicted_vx *= FRICTION
                    predicted_vy *= FRICTION
    
    def check_wall_collision(self, board_rect):
        if self.x - self.radius < board_rect.left:
            self.x = board_rect.left + self.radius
            self.vx = -self.vx * 0.8
        elif self.x + self.radius > board_rect.right:
            self.x = board_rect.right - self.radius
            self.vx = -self.vx * 0.8
        if self.y - self.radius < board_rect.top:
            self.y = board_rect.top + self.radius
            self.vy = -self.vy * 0.8
        elif self.y + self.radius > board_rect.bottom:
            self.y = board_rect.bottom - self.radius
            self.vy = -self.vy * 0.8
    
    def check_coin_collision(self, coin):
        if coin.in_pocket:
            return False
        
        dx = coin.x - self.x
        dy = coin.y - self.y
        distance = math.sqrt(dx**2 + dy**2)
        
        if distance < self.radius + coin.radius:
            nx = dx / distance
            ny = dy / distance
            rvx = coin.vx - self.vx
            rvy = coin.vy - self.vy
            velocity_along_normal = rvx * nx + rvy * ny
            
            if velocity_along_normal > 0:
                return False
            
            impulse = -(1 + 0.8) * velocity_along_normal
            impulse /= 1 / 1 + 1 / 1
            
            self.vx -= impulse * nx / 1
            self.vy -= impulse * ny / 1
            coin.vx += impulse * nx / 1
            coin.vy += impulse * ny / 1
            
            overlap = (self.radius + coin.radius - distance) * 0.5
            self.x -= overlap * nx
            self.y -= overlap * ny
            coin.x += overlap * nx
            coin.y += overlap * ny
            
            return True
        return False
    
    def strike(self, power, angle):
        self.vx = math.cos(angle) * power
        self.vy = math.sin(angle) * power
        self.visible = True  # Always visible

class CarromGame:
    def __init__(self):
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
        pygame.display.set_caption("Carrom Game - AI Course Project")
        self.clock = pygame.time.Clock()
        self.font = pygame.font.SysFont('Arial', 24)
        self.big_font = pygame.font.SysFont('Arial', 36)
        
        self.board_rect = pygame.Rect(
            (WIDTH - BOARD_SIZE) // 2,
            (HEIGHT - BOARD_SIZE) // 2,
            BOARD_SIZE,
            BOARD_SIZE
        )
        
        self.pockets = [
            (self.board_rect.left, self.board_rect.top),
            (self.board_rect.right, self.board_rect.top),
            (self.board_rect.left, self.board_rect.bottom),
            (self.board_rect.right, self.board_rect.bottom)
        ]
        
        # Adjusted line positions to be away from pockets
        self.player_line_y = self.board_rect.bottom - 70  # Changed from 50 to 70
        self.ai_line_y = self.board_rect.top + 70  # Changed from 50 to 70
        
        self.player_striker = Striker(
            self.board_rect.centerx,
            self.player_line_y,
            True
        )
        self.ai_striker = Striker(
            self.board_rect.centerx,
            self.ai_line_y,
            False
        )
        self.coins = []
        self.reset_game()
        
        self.game_state = PLAYER_TURN
        self.player_score = 0
        self.ai_score = 0
        self.last_scorer = None
        self.turn_message = "Click on your line to position striker"
        self.striker_moving = False
    
    def reset_game(self):
        self.coins = []
        self.coins.append(Coin(self.board_rect.centerx, self.board_rect.centery, RED, True))
        
        positions = self.get_coin_positions(5, 50)
        for pos in positions:
            self.coins.append(Coin(pos[0], pos[1], WHITE))
        
        positions = self.get_coin_positions(5, 50, offset=math.pi/5)
        for pos in positions:
            self.coins.append(Coin(pos[0], pos[1], BLACK))
        
        self.player_striker = Striker(
            self.board_rect.centerx,
            self.player_line_y,
            True
        )
        self.ai_striker = Striker(
            self.board_rect.centerx,
            self.ai_line_y,
            False
        )
        
        self.game_state = PLAYER_TURN
        self.player_score = 0
        self.ai_score = 0
        self.last_scorer = None
        self.turn_message = "Click on your line to position striker"
        self.striker_moving = False
        
        # Make player striker visible and AI striker invisible at start
        self.player_striker.visible = True
        self.ai_striker.visible = False
    
    def get_coin_positions(self, count, distance, offset=0):
        positions = []
        center_x, center_y = self.board_rect.centerx, self.board_rect.centery
        
        for i in range(count):
            angle = 2 * math.pi * i / count + offset
            x = center_x + distance * math.cos(angle)
            y = center_y + distance * math.sin(angle)
            positions.append((x, y))
        
        return positions
    
    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False
            
            if self.game_state == PLAYER_TURN and not self.striker_moving:
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    mouse_x, mouse_y = pygame.mouse.get_pos()
                    # Check if click is on the player's line
                    if abs(mouse_y - self.player_line_y) < 20:
                        self.player_striker.x = mouse_x
                        # Keep striker within board bounds
                        self.player_striker.x = max(
                            self.board_rect.left + self.player_striker.radius,
                            min(self.board_rect.right - self.player_striker.radius, self.player_striker.x)
                        )
                        self.player_striker.charging = True
                        self.turn_message = "Drag to aim, release to strike"
                
                if event.type == pygame.MOUSEMOTION and self.player_striker.charging:
                    mouse_x, mouse_y = pygame.mouse.get_pos()
                    dx = self.player_striker.x - mouse_x
                    dy = self.player_striker.y - mouse_y
                    self.player_striker.angle = math.atan2(dy, dx)
                    self.player_striker.power = min(math.sqrt(dx**2 + dy**2) / 8, self.player_striker.max_power)
                
                if event.type == pygame.MOUSEBUTTONUP and event.button == 1 and self.player_striker.charging:
                    self.player_striker.strike(self.player_striker.power, self.player_striker.angle)
                    self.player_striker.charging = False
                    self.game_state = WAITING_FOR_STRIKE
                    self.turn_message = "Waiting for coins to stop..."
                    self.striker_moving = True
            
            if event.type == pygame.USEREVENT:
                if self.game_state == AI_TURN:
                    self.ai_turn()
            
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_r:
                    self.reset_game()
        
        return True
    
    def update(self):
        self.player_striker.update()
        self.ai_striker.update()
        
        for coin in self.coins:
            coin.update()
        
        self.check_collisions()
        
        if all(coin.in_pocket for coin in self.coins):
            self.game_state = GAME_OVER
            return
        
        moving = False
        
        if (abs(self.player_striker.vx) > MIN_VELOCITY or 
            abs(self.player_striker.vy) > MIN_VELOCITY or
            abs(self.ai_striker.vx) > MIN_VELOCITY or 
            abs(self.ai_striker.vy) > MIN_VELOCITY):
            moving = True
        
        for coin in self.coins:
            if (abs(coin.vx) > MIN_VELOCITY or abs(coin.vy) > MIN_VELOCITY) and not coin.in_pocket:
                moving = True
                break
        
        self.striker_moving = moving
        
        if not moving and self.game_state == WAITING_FOR_STRIKE:
            player_pocketed = False
            ai_pocketed = False
            
            for coin in self.coins:
                if coin.in_pocket and coin.pocketed_this_turn:
                    if self.last_scorer == 'player':
                        player_pocketed = True
                    elif self.last_scorer == 'ai':
                        ai_pocketed = True
            
            if self.last_scorer == 'player' and player_pocketed:
                self.game_state = PLAYER_TURN
                self.turn_message = "Click on your line to position striker"
                self.player_striker.reset_position()
                self.player_striker.visible = True  # Make player striker visible
                self.ai_striker.visible = False    # Make AI striker invisible
            elif self.last_scorer == 'ai' and ai_pocketed:
                self.game_state = AI_TURN
                self.turn_message = "AI's turn!"
                self.ai_striker.reset_position()
                self.player_striker.visible = False  # Make player striker invisible
                self.ai_striker.visible = True       # Make AI striker visible
                pygame.time.set_timer(pygame.USEREVENT, 1000, True)
            else:
                if self.last_scorer == 'player':
                    self.game_state = AI_TURN
                    self.turn_message = "AI's turn!"
                    self.ai_striker.reset_position()
                    self.player_striker.visible = False  # Make player striker invisible
                    self.ai_striker.visible = True       # Make AI striker visible
                    pygame.time.set_timer(pygame.USEREVENT, 1000, True)
                else:
                    self.game_state = PLAYER_TURN
                    self.turn_message = "Click on your line to position striker"
                    self.player_striker.reset_position()
                    self.player_striker.visible = True  # Make player striker visible
                    self.ai_striker.visible = False    # Make AI striker invisible
            
            for coin in self.coins:
                coin.pocketed_this_turn = False
    
    def ai_turn(self):
        best_coin = None
        best_score = -1
        best_power = 0
        best_angle = 0
        
        for coin in self.coins:
            if not coin.in_pocket:
                dx = coin.x - self.ai_striker.x
                dy = coin.y - self.ai_striker.y
                distance = math.sqrt(dx**2 + dy**2)
                angle = math.atan2(dy, dx) + random.uniform(-0.1, 0.1)
                power = min(distance / 8 + random.uniform(8, 12), self.ai_striker.max_power)
                
                if coin.color == RED:
                    score = 20 / (distance + 1)
                elif coin.color == WHITE:
                    score = 10 / (distance + 1)
                else:
                    score = 5 / (distance + 1)
                
                score *= random.uniform(0.8, 1.2)
                
                if score > best_score:
                    best_score = score
                    best_coin = coin
                    best_power = power
                    best_angle = angle
        
        if best_coin:
            # Position AI striker randomly along its line
            self.ai_striker.x = random.randint(
                self.board_rect.left + self.ai_striker.radius,
                self.board_rect.right - self.ai_striker.radius
            )
            self.ai_striker.strike(best_power, best_angle)
            self.game_state = WAITING_FOR_STRIKE
            self.turn_message = "Waiting for coins to stop..."
            self.striker_moving = True
    
    def check_collisions(self):
        self.player_striker.check_wall_collision(self.board_rect)
        self.ai_striker.check_wall_collision(self.board_rect)
        
        for coin in self.coins:
            coin.check_wall_collision(self.board_rect)
        
        for coin in self.coins:
            if not coin.in_pocket and coin.check_pocket_collision(self.pockets):
                if coin.color == WHITE:
                    if self.last_scorer == 'player':
                        self.player_score += 10
                    elif self.last_scorer == 'ai':
                        self.ai_score += 10
                elif coin.color == BLACK:
                    if self.last_scorer == 'player':
                        self.player_score += 5
                    elif self.last_scorer == 'ai':
                        self.ai_score += 5
                elif coin.color == RED:
                    if self.last_scorer == 'player':
                        self.player_score += 20
                    elif self.last_scorer == 'ai':
                        self.ai_score += 20
        
        for coin in self.coins:
            if self.player_striker.check_coin_collision(coin):
                self.last_scorer = 'player'
            if self.ai_striker.check_coin_collision(coin):
                self.last_scorer = 'ai'
        
        for i in range(len(self.coins)):
            for j in range(i + 1, len(self.coins)):
                self.coins[i].check_coin_collision(self.coins[j])
    
    def draw(self):
        self.screen.fill((50, 50, 50))
        pygame.draw.rect(self.screen, BOARD_COLOR, self.board_rect)
        pygame.draw.rect(self.screen, LINE_COLOR, self.board_rect, 5)
        
        for pocket in self.pockets:
            pygame.gfxdraw.filled_circle(self.screen, int(pocket[0]), int(pocket[1]), POCKET_RADIUS, BLACK)
            pygame.gfxdraw.aacircle(self.screen, int(pocket[0]), int(pocket[1]), POCKET_RADIUS, BLACK)
        
        pygame.gfxdraw.aacircle(
            self.screen, 
            self.board_rect.centerx, 
            self.board_rect.centery, 
            50, 
            LINE_COLOR
        )
        
        # Draw the striker lines (adjusted to be away from pockets)
        pygame.draw.line(
            self.screen, 
            LINE_COLOR, 
            (self.board_rect.left, self.player_line_y),
            (self.board_rect.right, self.player_line_y),
            2
        )
        pygame.draw.line(
            self.screen, 
            LINE_COLOR, 
            (self.board_rect.left, self.ai_line_y),
            (self.board_rect.right, self.ai_line_y),
            2
        )
        
        for coin in self.coins:
            coin.draw(self.screen)
        
        # Draw strikers based on visibility
        self.player_striker.draw(self.screen, self.game_state, self.board_rect)
        self.ai_striker.draw(self.screen, self.game_state, self.board_rect)
        
        player_text = self.font.render(f"Player: {self.player_score}", True, WHITE)
        ai_text = self.font.render(f"AI: {self.ai_score}", True, WHITE)
        self.screen.blit(player_text, (20, 20))
        self.screen.blit(ai_text, (WIDTH - 100, 20))
        
        turn_text = self.font.render(self.turn_message, True, WHITE)
        self.screen.blit(turn_text, (WIDTH // 2 - turn_text.get_width() // 2, 20))
        
        if self.game_state == PLAYER_TURN and not self.striker_moving:
            instr_text = self.font.render("Click on your line to position striker, then drag to aim", True, (200, 200, 255))
            self.screen.blit(instr_text, (WIDTH // 2 - instr_text.get_width() // 2, HEIGHT - 30))
        
        if self.game_state == GAME_OVER:
            if self.player_score > self.ai_score:
                result_text = self.big_font.render("Player Wins!", True, (0, 255, 0))
            elif self.ai_score > self.player_score:
                result_text = self.big_font.render("AI Wins!", True, (255, 0, 0))
            else:
                result_text = self.big_font.render("It's a Tie!", True, (255, 255, 0))
            
            restart_text = self.font.render("Press R to restart", True, WHITE)
            
            self.screen.blit(result_text, 
                           (WIDTH // 2 - result_text.get_width() // 2, 
                            HEIGHT // 2 - result_text.get_height() // 2))
            self.screen.blit(restart_text, 
                           (WIDTH // 2 - restart_text.get_width() // 2, 
                            HEIGHT // 2 + 50))
        
        pygame.display.flip()
    
    def run(self):
        running = True
        while running:
            running = self.handle_events()
            self.update()
            self.draw()
            self.clock.tick(60)
        
        pygame.quit()
        sys.exit()

if __name__ == "__main__":
    game = CarromGame()
    game.run()